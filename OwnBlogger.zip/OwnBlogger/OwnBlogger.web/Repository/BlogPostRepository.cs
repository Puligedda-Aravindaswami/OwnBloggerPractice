﻿using Azure;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.EntityFrameworkCore;
using OwnBlogger.web.Data;
using OwnBlogger.web.Models.Domain;
using OwnBlogger.web.Models.ViewModels;
using System.Reflection.Metadata;

namespace OwnBlogger.web.Repository
{
    public class BlogPostRepository : IBlogPostRepository
    {
        private readonly OwnBloggerDbContext ownBloggerDbContext;

        public BlogPostRepository(OwnBloggerDbContext ownBloggerDbContext)
        {
            this.ownBloggerDbContext = ownBloggerDbContext;
        }
        public async Task<BlogPost> AddAsync(BlogPost post)
        {
            await  this.ownBloggerDbContext.AddAsync(post);

            await this.ownBloggerDbContext.SaveChangesAsync();

            return post;
        }

        public async Task<BlogPost?> DeleteAsync(Guid id)
        {
            var existingBlogpost = await ownBloggerDbContext.BlogPosts.FindAsync(id);
            if (existingBlogpost != null)
            {
                // ownBloggerDbContext.Remove(existingTag); both are working
                ownBloggerDbContext.BlogPosts.Remove(existingBlogpost);
                await ownBloggerDbContext.SaveChangesAsync();
            }
            return existingBlogpost;
        }

        public async Task<IEnumerable<BlogPost>> GetAllAsync()
        {
           return await ownBloggerDbContext.BlogPosts.Include(x=>x.Tags).ToListAsync();
        }

        public async Task<BlogPost?> GetAsync(Guid id)
        {
            return await ownBloggerDbContext.BlogPosts.Include(x=>x.Tags).FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<BlogPost?> UpdateAsync(BlogPost post)
        {

            var existingBlogPost = await ownBloggerDbContext.BlogPosts.Include(x => x.Tags).FirstOrDefaultAsync(x => x.Id == post.Id);
            if (existingBlogPost != null)
            {
               
                existingBlogPost.Heading = post.Heading;
                existingBlogPost.PageTitle = post.PageTitle;
                existingBlogPost.Content = post.Content;
                existingBlogPost.ShortDescription = post.ShortDescription;
                existingBlogPost.FeaturedImageUrl = post.FeaturedImageUrl;
                existingBlogPost.UrlHandle = post.UrlHandle;
                existingBlogPost.PublishedDate = post.PublishedDate;
                existingBlogPost.Author = post.Author;
                existingBlogPost.Visible = post.Visible;
                existingBlogPost.Tags = post.Tags;
                
                await ownBloggerDbContext.SaveChangesAsync();
            }
            return existingBlogPost;
        }
    }
}

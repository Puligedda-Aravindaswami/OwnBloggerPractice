﻿using OwnBlogger.web.Models.Domain;

namespace OwnBlogger.web.Repository
{
    public interface IBlogPostRepository
    {
        Task<IEnumerable<BlogPost>> GetAllAsync();
        Task<BlogPost?> GetAsync(Guid id);
        Task<BlogPost> AddAsync(BlogPost tag);
        Task<BlogPost?> UpdateAsync(BlogPost tag);
        Task<BlogPost?> DeleteAsync(Guid id);
    }
}

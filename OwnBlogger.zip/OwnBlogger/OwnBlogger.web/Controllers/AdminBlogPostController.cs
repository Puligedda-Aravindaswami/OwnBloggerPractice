﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using OwnBlogger.web.Data;
using OwnBlogger.web.Models.Domain;
using OwnBlogger.web.Models.ViewModels;
using OwnBlogger.web.Repository;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;

namespace OwnBlogger.web.Controllers
{
    public class AdminBlogPostController : Controller
    {
        private readonly ITagRepository tagRepository;
        private readonly IBlogPostRepository blogPostRepository;

        public AdminBlogPostController(ITagRepository tagRepository, IBlogPostRepository blogPostRepository)
        {
            this.tagRepository = tagRepository;
            this.blogPostRepository = blogPostRepository;
        }

        [HttpGet]
        public async Task<IActionResult> Add()
        {
            //get Tags
            var tags = await tagRepository.GetAllAsync();
            var model = new AddBlogPostRequest
            {
                Tags = tags.Select(x => new SelectListItem { Text = x.Name, Value = x.Id.ToString() })
            };

            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> Add(AddBlogPostRequest addBlogPostRequest)
    {
            var blog = new BlogPost
            {
                Heading = addBlogPostRequest.Heading,
                PageTitle = addBlogPostRequest.PageTitle,
                Content = addBlogPostRequest.Content,
                ShortDescription = addBlogPostRequest.ShortDescription,
                FeaturedImageUrl = addBlogPostRequest.FeaturedImageUrl,
                UrlHandle = addBlogPostRequest.UrlHandle,
                PublishedDate = addBlogPostRequest.PublishedDate,
                Author = addBlogPostRequest.Author,
                Visible = addBlogPostRequest.Visible
            };
            var selectedTags=new List<Tag>();
            foreach (var selectedTagId in addBlogPostRequest.SelectedTags)
            {
                var existingTag =await tagRepository.GetAsync(Guid.Parse(selectedTagId));
                if (existingTag != null)
                {
                    selectedTags.Add(existingTag);
                }
            }
            blog.Tags= selectedTags;
           await blogPostRepository.AddAsync(blog);  
        return RedirectToAction("Add");
    }

        [HttpGet]
        public async Task<IActionResult> List()
        {
          var allBlogs=  await blogPostRepository.GetAllAsync();
            return View(allBlogs);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            //1st method
            //var tag= ownBloggerDbContext.Tags.Find(id);
            //2nd method

            //DataBase methods calling using repository Pattern
            var post = await blogPostRepository.GetAsync(id);
            var tagdomainModel = await tagRepository.GetAllAsync();
            if (post != null)
            {

                var editBlogPostRequest = new EditBlogPostRequest
                {
                    Id=post.Id,
                    Heading = post.Heading,
                    PageTitle = post.PageTitle,
                    Content = post.Content,
                    ShortDescription = post.ShortDescription,
                    FeaturedImageUrl = post.FeaturedImageUrl,
                    UrlHandle = post.UrlHandle,
                    PublishedDate = post.PublishedDate,
                    Author = post.Author,
                    Visible = post.Visible,
                    Tags = tagdomainModel.Select(x => new SelectListItem
                    {
                        Text = x.Name,
                        Value = x.Id.ToString()
                    }),
                    SelectedTags = post.Tags.Select(x => x.Id.ToString()).ToArray()



                };
                return View(editBlogPostRequest);
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Edit(EditBlogPostRequest editBlogPostRequest)
        {
            var selectedTags = new List<Tag>();
            foreach (var selectedTagId in editBlogPostRequest.SelectedTags)
            {
                var existingTag = await tagRepository.GetAsync(Guid.Parse(selectedTagId));
                if (existingTag != null)
                {
                    selectedTags.Add(existingTag);
                }
            }

            var post = new BlogPost
            {
                Id = editBlogPostRequest.Id,
                Heading = editBlogPostRequest.Heading,
                PageTitle = editBlogPostRequest.PageTitle,
                Content = editBlogPostRequest.Content,
                ShortDescription = editBlogPostRequest.ShortDescription,
                FeaturedImageUrl = editBlogPostRequest.FeaturedImageUrl,
                UrlHandle = editBlogPostRequest.UrlHandle,
                PublishedDate = editBlogPostRequest.PublishedDate,
                Author = editBlogPostRequest.Author,
                Visible = editBlogPostRequest.Visible,
                Tags = selectedTags
    };
            
            //DataBase methods calling using repository Pattern
            var Updatedtag = await blogPostRepository.UpdateAsync(post);

            if (Updatedtag != null)
            {
                return RedirectToAction("List");
            }


            return RedirectToAction("Edit", new { id = editBlogPostRequest.Id });

        }

        [HttpGet]
        public async Task<IActionResult> Delete(Guid id)
        {
            await blogPostRepository.DeleteAsync(id);
            return RedirectToAction("List");
        }

    }
}
        




   

  


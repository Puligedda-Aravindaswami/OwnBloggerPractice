﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OwnBlogger.web.Repository;
using System.Net;

namespace OwnBlogger.web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly IImageRepository imageRepository;

        public ImagesController(IImageRepository imageRepository)
        {
            this.imageRepository = imageRepository;
        }
        [HttpPost]
        public async Task<IActionResult> uploadAsync(IFormFile file)
        {
            var imageURL= await imageRepository.UploadAsync(file);
            if (imageURL!=null)
            {
                return new JsonResult(new { link = imageURL });
            }
           
                return Problem("Something went wrong in Image upload!", null, (int)HttpStatusCode.InternalServerError);
            
        }
    }
}

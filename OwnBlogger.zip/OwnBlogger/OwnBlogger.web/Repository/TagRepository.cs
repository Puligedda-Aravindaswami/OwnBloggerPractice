﻿using Microsoft.EntityFrameworkCore;
using OwnBlogger.web.Data;
using OwnBlogger.web.Models.Domain;

namespace OwnBlogger.web.Repository
{
    public class TagRepository : ITagRepository
    {
        private readonly OwnBloggerDbContext ownBloggerDbContext;

        public TagRepository(OwnBloggerDbContext ownBloggerDbContext)
        {
            this.ownBloggerDbContext = ownBloggerDbContext;
        }
        public async Task<Tag> AddAsync(Tag tag)
        {
            await this.ownBloggerDbContext.AddAsync(tag);
            await this.ownBloggerDbContext.SaveChangesAsync();
            return tag;
        }

        public async Task<Tag?> DeleteAsync(Guid id)
        {
            var existingTag = await ownBloggerDbContext.Tags.FindAsync(id);
            if (existingTag != null)
            {
                // ownBloggerDbContext.Remove(existingTag); both are working
                ownBloggerDbContext.Tags.Remove(existingTag);
                await ownBloggerDbContext.SaveChangesAsync();
            }
            return existingTag;
        }
        public async Task<IEnumerable<Tag>> GetAllAsync()
        {
            return await this.ownBloggerDbContext.Tags.ToListAsync();
        }

        public async Task<Tag?> GetAsync(Guid id)
        {
          return  await ownBloggerDbContext.Tags.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<Tag?> UpdateAsync(Tag tag)
        {
            var existingTag = await ownBloggerDbContext.Tags.FindAsync(tag.Id);
            if (existingTag != null)
            {
                existingTag.Name = tag.Name;
                existingTag.DisplayName = tag.DisplayName;
                await ownBloggerDbContext.SaveChangesAsync();
            }
            return existingTag;
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using OwnBlogger.web.Models.Domain;

namespace OwnBlogger.web.Data
{
    public class OwnBloggerDbContext : DbContext
    {
        public OwnBloggerDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<BlogPost> BlogPosts { get; set; }
        public DbSet<Tag> Tags { get; set; }    
    }
}

﻿using Azure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OwnBlogger.web.Data;
using OwnBlogger.web.Models.Domain;
using OwnBlogger.web.Models.ViewModels;
using OwnBlogger.web.Repository;
using System.Runtime.CompilerServices;

namespace OwnBlogger.web.Controllers
{
    public class AdminTagsController : Controller
    {
        
        private readonly ITagRepository tagRepository;

        public AdminTagsController(ITagRepository tagRepository)
        {
            this.tagRepository = tagRepository;
        }

        

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        
        [HttpPost]
        [ActionName("Add")] //we need to mention this ActionName or make method name as ADD this post method from Add view
        public async Task<IActionResult> Submit(AddTagRequest addTagRequest)
        {
            //var name = Request.Form["name"];need to add name="name" in cshtml input form tag and it traditional way of data binding
            //var displayName = Request.Form["displayName"];

            //modelBinding--to check values only
            //var name = addTagRequest.Name;
            // var DisplayName = addTagRequest.DisplayName;

            //Mapping AddRequestTag to Tag Domain model  
            var tag = new Tag
            {
                Name = addTagRequest.Name,
                DisplayName = addTagRequest.DisplayName
            };
            //Database binding
            //await this.ownBloggerDbContext.AddAsync(tag);
            //await this.ownBloggerDbContext.SaveChangesAsync();

            //DataBase methods calling using repository Pattern
            await tagRepository.AddAsync(tag);
            return RedirectToAction("List");
        }

        [HttpGet]
        
        public async Task<IActionResult> List()
        {
            //Use DbContext to read Tags from Database
            //var TagsList= await this.ownBloggerDbContext.Tags.ToListAsync();

            //DataBase methods calling using repository Pattern
            var TagsList = await tagRepository.GetAllAsync();
            return View(TagsList);  
        }

        [HttpGet]
        public async Task<IActionResult> Edit(Guid id) 
        {
            //1st method
            //var tag= ownBloggerDbContext.Tags.Find(id);
            //2nd method

            //DataBase methods calling using repository Pattern
            var tag =await tagRepository.GetAsync(id);
            if (tag!=null) 
            {
                var editTagRequest = new EditTagRequest
                {
                   Id = tag.Id,
                   Name = tag.Name,
                   DisplayName = tag.DisplayName
                };
                return View(editTagRequest);
            }
            return View();
        }
        [HttpPost]
        [ActionName("Edit")]
        public async Task<IActionResult> Save(EditTagRequest editTagRequest)
        {
            //need to convert editViewmodel objects to Tag Domain model as DbContext only cares domain models
            var tag = new Tag
            {
                Id= editTagRequest.Id,
                Name = editTagRequest.Name,
                DisplayName = editTagRequest.DisplayName
            };
            //var existingTag= ownBloggerDbContext.Tags.Find(tag.Id);
            //if (existingTag!=null)
            //{
            //    existingTag.Name = tag.Name;
            //    existingTag.DisplayName = tag.DisplayName;
            //    await ownBloggerDbContext.SaveChangesAsync();

            //DataBase methods calling using repository Pattern
            var Updatedtag = await tagRepository.UpdateAsync(tag);

            if (Updatedtag != null)
            {
                return RedirectToAction("List");
            }
                
            
            return RedirectToAction("Edit",new {id = editTagRequest.Id});

        }

        [HttpGet]
        public async Task<IActionResult> Delete(Guid id)
        {
            //var existingTag = ownBloggerDbContext.Tags.Find(id);
            //if (existingTag != null)
            //{
            //    // ownBloggerDbContext.Remove(existingTag); both are working
            //     ownBloggerDbContext.Tags.Remove(existingTag);
            //    await ownBloggerDbContext.SaveChangesAsync();

            //DataBase methods calling using repository Pattern
            await tagRepository.DeleteAsync(id);
                return RedirectToAction("List");
            
            
        }

    }
}
